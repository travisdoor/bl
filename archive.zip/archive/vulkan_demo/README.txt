This is simple vulkan API demo created in BL.

* You will need Vulkan SDK: https://vulkan.lunarg.com installed on your system.
* Run blc -r src/vulkan_demo.bl to compile and execute demo.
