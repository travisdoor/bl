This is simple SDL game created in BL.

* You will need SDL2 and SDL_Image installed on your system.
* Run blc -r src/skyshooter.bl to compile and execute demo.
